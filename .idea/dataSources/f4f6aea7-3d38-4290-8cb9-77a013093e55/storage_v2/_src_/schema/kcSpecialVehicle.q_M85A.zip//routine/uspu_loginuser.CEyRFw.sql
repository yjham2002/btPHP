create procedure uspU_loginUser(IN pi_userID          varchar(128), IN pi_deviceID varchar(128), IN pi_deviceTypeID int,
                                IN pi_registrationKey varchar(256), IN pi_appVersion varchar(20))
  BEGIN
	DECLARE v_userNumber	INT DEFAULT 0;
	DECLARE v_userPWD	VARCHAR(256);
	DECLARE v_status	INT DEFAULT 0;	
	DECLARE v_returnCode	INT;
	DECLARE v_returnMsg	VARCHAR(512);
	
	-- 회원 정보 조회
	SELECT userNo, STATUS INTO v_userNumber, v_status
	FROM tblUser
	WHERE userID = pi_userID AND STATUS=1
	LIMIT 1;
	
	IF (v_userNumber = 0) THEN 
		SET v_returnCode	= '-100';
		SET v_returnMsg		= '가입되지 않은 회원입니다.';
		SET v_userNumber	= 0;
	ELSE
		-- 중복 푸시키 제거
		UPDATE tblUser
		SET registrationKey = ''
		WHERE registrationKey = pi_registrationKey;
		
		-- 회원정보 갱신
		UPDATE tblUser
		SET
			registrationKey	= CASE WHEN CHAR_LENGTH(pi_registrationKey) > 16 THEN pi_registrationKey ELSE '' END,
			deviceId	= pi_deviceID,
			deviceTypeID	= pi_deviceTypeID,
			appVersion	= pi_appVersion,
			lastLoginDate	= NOW()
		WHERE userNo = v_userNumber;
				
		SET v_returnCode	= '1';
		SET v_returnMsg		= '로그인 되었습니다.';
		
	END IF;
	
	SELECT v_returnCode, v_returnMsg, v_userNumber;
	
    END;

