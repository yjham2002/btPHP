create procedure uspU_autoLogin(IN  pi_userNumber      int, IN pi_deviceID varchar(128), IN pi_deviceTypeID int,
                                IN  pi_registrationKey varchar(256), IN pi_appVersion varchar(10),
                                OUT po_returnCode      int, OUT po_returnMsg varchar(512))
  BEGIN
    
	DECLARE v_userNumber 		INT DEFAULT 0;
	DECLARE v_deviceID 		VARCHAR(256) DEFAULT NULL;
	DECLARE v_availChangeDate	DATE DEFAULT NULL;
	
	SELECT userNo, deviceID INTO v_userNumber, v_deviceID
	FROM tblUser
	WHERE userNo = pi_userNumber AND STATUS =1
	LIMIT 1;
    
	IF (v_userNumber = 0) THEN 
	
		SET po_returnCode	= '-100';
		SET po_returnMsg	= "로그인을 해주세요.";
		
	ELSE
	
		-- 중복 푸시키 제거
		UPDATE tblUser
		SET registrationKey = ''
		WHERE registrationKey = pi_registrationKey;
	
		/* 사용자 정보 갱신 */
		UPDATE tblUser
		SET	lastLoginDate = NOW(), appVersion = pi_appVersion,
			registrationKey = CASE WHEN CHAR_LENGTH(pi_registrationKey) > 32 THEN pi_registrationKey ELSE '' END,
			deviceId	= pi_deviceID,
			deviceTypeID	= pi_deviceTypeID
		WHERE userNo = pi_userNumber;
				
		SET po_returnCode = '1';
		SET po_returnMsg = "로그인 되었습니다.";
		
	END IF;
	
	SELECT po_returnCode, po_returnMsg;
    END;

